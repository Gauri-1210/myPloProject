class AppConstants {
  static String location = "assets/images/";

  static var apphorizontal;
}
