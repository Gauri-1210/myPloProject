import 'package:my_plo/theme/imagetheme/app_constants.dart';

class Images {
  static String finalLocation = "${AppConstants.location}location.png";

  static String finalProfile = "${AppConstants.location}profile.jpg";
  final imageUrl =
      'https://www.sugar.org/wp-content/uploads/Birthday-Cake-1.png';
}
