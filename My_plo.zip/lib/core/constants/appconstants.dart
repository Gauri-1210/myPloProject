class AppConstants {
  static const double apphorizontal = 15.0;
}
